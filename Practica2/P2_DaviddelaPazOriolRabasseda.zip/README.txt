To execute the program go to src folder and use the following instructions:

make
./main ./dades/dades.csv ./aeroports/aeroports.csv <origin>

Where <origin> is the IATA code of the specified airport.